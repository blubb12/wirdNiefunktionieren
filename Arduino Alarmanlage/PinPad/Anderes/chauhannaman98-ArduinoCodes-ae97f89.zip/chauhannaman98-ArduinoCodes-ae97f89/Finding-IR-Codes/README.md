# Introduction

Most of the appliances from TV, DTH receiver , DVD Players to AC, etc are controlled wirelessly using IR remotes.

If you want to make an IR based project with a remote which you bought from the market or the remote of your AC, TV ,etc. then, you should be aware of the codes which are sent by the remote to the IR receiver in the appliance or device.

Click [here](https://www.hackster.io/techmirtz/finding-the-ir-codes-of-any-ir-remote-using-arduino-c7a852) to open the project on Hackster.io.

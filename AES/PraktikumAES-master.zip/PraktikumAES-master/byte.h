#ifndef _byte_h_
#define _byte_h_

/** Definition of type byte */
#ifndef byte
typedef unsigned char byte;
#endif

#endif 
